package sawit.exception;

/** Dilempar saat pengiriman melebihi stok TBS yang tersedia. */
public class StokTidakCukupException extends Exception {
    private final double diminta, tersedia;
    public StokTidakCukupException(double diminta, double tersedia) {
        super(String.format("Stok tidak cukup. Diminta %,.0f kg, tersedia %,.0f kg", diminta, tersedia));
        this.diminta = diminta; this.tersedia = tersedia;
    }
    public double getDiminta() { return diminta; }
    public double getTersedia() { return tersedia; }
}
