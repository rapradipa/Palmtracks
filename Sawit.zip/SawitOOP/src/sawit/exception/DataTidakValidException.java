package sawit.exception;

/** Dilempar saat input/data tidak valid (kosong, bukan angka, format tanggal salah, ID ganda, dst). */
public class DataTidakValidException extends Exception {
    public DataTidakValidException(String pesan) { super(pesan); }
}
