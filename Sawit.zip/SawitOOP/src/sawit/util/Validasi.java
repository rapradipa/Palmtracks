package sawit.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import sawit.exception.DataTidakValidException;

/** Utility validasi & konversi input teks -> tipe data. */
public final class Validasi {
    private Validasi() { }

    public static String teks(String s, String field) throws DataTidakValidException {
        if (s == null || s.trim().isEmpty()) throw new DataTidakValidException(field + " wajib diisi");
        return s.trim();
    }

    public static double desimal(String s, String field) throws DataTidakValidException {
        double d;
        try { d = Double.parseDouble(teks(s, field).replace(",", ".")); }
        catch (NumberFormatException e) { throw new DataTidakValidException(field + " harus berupa angka"); }
        if (d < 0) throw new DataTidakValidException(field + " tidak boleh negatif");
        return d;
    }

    public static int bulat(String s, String field) throws DataTidakValidException {
        int n;
        try { n = Integer.parseInt(teks(s, field)); }
        catch (NumberFormatException e) { throw new DataTidakValidException(field + " harus berupa bilangan bulat"); }
        if (n < 0) throw new DataTidakValidException(field + " tidak boleh negatif");
        return n;
    }

    public static LocalDate tanggal(String s, String field) throws DataTidakValidException {
        try { return LocalDate.parse(teks(s, field)); }
        catch (DateTimeParseException e) { throw new DataTidakValidException(field + " harus berformat yyyy-MM-dd"); }
    }
}
