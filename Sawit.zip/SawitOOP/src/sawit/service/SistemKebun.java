package sawit.service;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import sawit.exception.DataTidakValidException;
import sawit.exception.StokTidakCukupException;
import sawit.model.*;

/** Facade: pusat logika bisnis & penyimpanan file. */
public class SistemKebun {
    private static final String FILE = "data_sawit.dat";
    private Repository<Lahan> lahan = new Repository<>();
    private Repository<Bibit> bibit = new Repository<>();
    private Repository<Penanaman> penanaman = new Repository<>();
    private Repository<Perawatan> perawatan = new Repository<>();
    private Repository<Monitoring> monitoring = new Repository<>();
    private Repository<Panen> panen = new Repository<>();
    private Repository<Stok> stok = new Repository<>();
    private Repository<Pengiriman> pengiriman = new Repository<>();
    private Repository<Modal> modal = new Repository<>();
    private Repository<BiayaOperasional> biaya = new Repository<>();

    public Repository<Lahan> getLahan() { return lahan; }
    public Repository<Bibit> getBibit() { return bibit; }
    public Repository<Penanaman> getPenanaman() { return penanaman; }
    public Repository<Perawatan> getPerawatan() { return perawatan; }
    public Repository<Monitoring> getMonitoring() { return monitoring; }
    public Repository<Panen> getPanen() { return panen; }
    public Repository<Stok> getStok() { return stok; }
    public Repository<Pengiriman> getPengiriman() { return pengiriman; }
    public Repository<Modal> getModal() { return modal; }
    public Repository<BiayaOperasional> getBiaya() { return biaya; }

    // ---- Proses bisnis ----
    /** Panen dicatat, lalu otomatis menambah stok TBS. */
    public void catatPanen(Panen p) throws DataTidakValidException {
        p.catatPanen(panen, stok);
    }

    /** Pengiriman divalidasi terhadap stok, lalu stok dikurangi (FIFO). */
    public void catatPengiriman(Pengiriman p) throws DataTidakValidException, StokTidakCukupException {
        p.catatPengiriman(pengiriman, stok);
    }

    // ---- Agregasi ----
    public double hitungStokTersedia() { return Stok.hitungTotalStok(stok); }
    public double hitungTotalLuas() { double t = 0; for (Lahan l : lahan.getAll()) t += l.getLuasLahan(); return t; }
    public int hitungJumlahBibit() { return Bibit.hitungJumlahBibit(bibit); }
    public int hitungJumlahPohonTanam() { int t = 0; for (Penanaman p : penanaman.getAll()) t += p.hitungJumlahPohon(); return t; }
    public double hitungBeratTBS() { double t = 0; for (Panen p : panen.getAll()) t += p.hitungBeratTBS(); return t; }
    public int hitungJumlahTandan() { int t = 0; for (Panen p : panen.getAll()) t += p.hitungJumlahTandan(); return t; }
    public double hitungTotalModal() { return Modal.hitungTotalModal(modal); }

    /** POLYMORPHISM: tiga class berbeda diperlakukan sebagai Biayaable. */
    public double hitungTotalBiayaKeseluruhan() {
        List<Biayaable> semua = new ArrayList<>();
        semua.addAll(perawatan.getAll()); semua.addAll(biaya.getAll()); semua.addAll(pengiriman.getAll());
        double t = 0;
        for (Biayaable b : semua) t += b.getBiaya();
        return t;
    }

    private Monitoring terakhir() { return monitoring.getAll().stream().max(Comparator.comparing(Monitoring::getTanggal)).orElse(null); }
    public int hitungPohonHidup() { Monitoring m = terakhir(); return m == null ? 0 : m.hitungPohonHidup(); }

    public PrediksiPanen buatPrediksi() {
        Monitoring m = terakhir();
        return new PrediksiPanen("PR-1", hitungTotalLuas(), hitungPohonHidup(), m == null ? 0 : m.getUmurTanaman());
    }
    public AnalisisKeuangan buatAnalisis(double hargaPerKg) {
        return new AnalisisKeuangan("AK-1", hitungBeratTBS(), hargaPerKg, hitungTotalBiayaKeseluruhan(), hitungTotalModal());
    }

    // ---- Penyimpanan file (serialization) ----
    public void simpan() throws IOException {
        try (ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(FILE))) {
            o.writeObject(lahan); o.writeObject(bibit); o.writeObject(penanaman); o.writeObject(perawatan); o.writeObject(monitoring);
            o.writeObject(panen); o.writeObject(stok); o.writeObject(pengiriman); o.writeObject(modal); o.writeObject(biaya);
        }
    }

    @SuppressWarnings("unchecked")
    public boolean muat() throws IOException, ClassNotFoundException {
        File f = new File(FILE);
        if (!f.exists()) return false;
        try (ObjectInputStream i = new ObjectInputStream(new FileInputStream(f))) {
            Repository<Lahan> a = (Repository<Lahan>) i.readObject();
            Repository<Bibit> b = (Repository<Bibit>) i.readObject();
            Repository<Penanaman> c = (Repository<Penanaman>) i.readObject();
            Repository<Perawatan> d = (Repository<Perawatan>) i.readObject();
            Repository<Monitoring> e = (Repository<Monitoring>) i.readObject();
            Repository<Panen> g = (Repository<Panen>) i.readObject();
            Repository<Stok> h = (Repository<Stok>) i.readObject();
            Repository<Pengiriman> j = (Repository<Pengiriman>) i.readObject();
            Repository<Modal> k = (Repository<Modal>) i.readObject();
            Repository<BiayaOperasional> l = (Repository<BiayaOperasional>) i.readObject();
            lahan = a; bibit = b; penanaman = c; perawatan = d; monitoring = e; panen = g; stok = h; pengiriman = j; modal = k; biaya = l;
        }
        return true;
    }

    public void isiDataContoh() throws DataTidakValidException {
        lahan.tambah(new Lahan("L001", "Kebun Utara", 100, 5));
        bibit.tambah(new Bibit("B001", LocalDate.of(2022, 1, 10), "Tenera DxP", 14000, "Baik"));
        penanaman.tambah(new Penanaman("T001", LocalDate.of(2022, 6, 15), "BLK-1", 13600, "Budi"));
        perawatan.tambah(new Perawatan("R001", LocalDate.of(2026, 3, 1), "NPK", 250, 3500000));
        monitoring.tambah(new Monitoring("M001", LocalDate.of(2026, 10, 1), 4, 13300, "Sehat"));
        catatPanen(new Panen("P001", LocalDate.of(2026, 10, 20), "BLK-1", 900, 9000, "Andi"));
        modal.tambah(new Modal("MD001", LocalDate.of(2022, 1, 1), 500000000, "Modal awal"));
        biaya.tambah(new BiayaOperasional("BO001", LocalDate.of(2026, 10, 5), "Upah", 8000000, "Gaji pekerja"));
    }
}
