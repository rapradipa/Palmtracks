package sawit.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import sawit.exception.DataTidakValidException;
import sawit.model.Entitas;

/** GENERIC class: penyimpanan CRUD untuk semua turunan Entitas. */
public class Repository<T extends Entitas> implements Serializable {
    private static final long serialVersionUID = 1L;
    private final List<T> data = new ArrayList<>();

    public void tambah(T t) throws DataTidakValidException {
        if (cari(t.getId()) != null) throw new DataTidakValidException("ID '" + t.getId() + "' sudah digunakan");
        data.add(t);
    }
    public void ubah(int idx, T baru) throws DataTidakValidException {
        for (int i = 0; i < data.size(); i++)
            if (i != idx && data.get(i).getId().equals(baru.getId())) throw new DataTidakValidException("ID '" + baru.getId() + "' sudah digunakan");
        data.set(idx, baru);
    }
    public void hapus(int idx) { data.remove(idx); }
    public void hapus(T t) { data.remove(t); }
    public T cari(String id) {
        for (T t : data) if (t.getId().equals(id)) return t;
        return null;
    }
    public List<T> getAll() { return Collections.unmodifiableList(data); }
}
