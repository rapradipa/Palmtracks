package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

public class Modal extends Transaksi {
    private static final long serialVersionUID = 1L;
    private double jumlahModal; private String keterangan;

    public Modal(String idModal, LocalDate tanggal, double jumlah, String ket) throws DataTidakValidException {
        super(idModal, tanggal); ubahDataModal(jumlah, ket);
    }
    public final void ubahDataModal(double jumlah, String ket) throws DataTidakValidException {
        if (jumlah <= 0) throw new DataTidakValidException("Jumlah modal harus lebih dari 0");
        this.jumlahModal = jumlah; this.keterangan = Validasi.teks(ket, "Keterangan");
    }
    public double getJumlahModal() { return jumlahModal; }
    public static Modal dari(String[] f) throws DataTidakValidException {
        return new Modal(f[0], Validasi.tanggal(f[1], "Tanggal modal"), Validasi.desimal(f[2], "Jumlah modal"), f[3]);
    }
    public String getIdModal() { return getId(); }
    public void catatModal(Repository<Modal> repo) throws DataTidakValidException { repo.tambah(this); }
    public static double hitungTotalModal(Repository<Modal> repo) { double t = 0; for (Modal m : repo.getAll()) t += m.getJumlahModal(); return t; }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), jumlahModal, keterangan}; }
    @Override protected String getJenis() { return "Modal"; }
    @Override protected String getDetail() { return String.format("Rp %,.0f - %s", jumlahModal, keterangan); }
}
