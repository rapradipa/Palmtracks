package sawit.model;

public class AnalisisKeuangan extends Laporan {
    private final double beratTBSkg, hargaPerKg, totalBiaya, totalModal;
    private double totalPendapatan, keuntungan, nilaiBEP;

    public AnalisisKeuangan(String id, double beratTBSkg, double hargaPerKg, double totalBiaya, double totalModal) {
        super(id); this.beratTBSkg = beratTBSkg; this.hargaPerKg = hargaPerKg; this.totalBiaya = totalBiaya; this.totalModal = totalModal;
    }
    public double hitungPendapatan() { return totalPendapatan = beratTBSkg * hargaPerKg; }
    public double hitungKeuntungan() { return keuntungan = totalPendapatan - totalBiaya; }
    public double hitungBEP() { return nilaiBEP = hargaPerKg == 0 ? 0 : totalBiaya / hargaPerKg; } // kg TBS
    public String tampilkanLaporanKeuangan() {
        return String.format("Total modal      : Rp %,.0f%nTotal pendapatan : Rp %,.0f%nTotal biaya      : Rp %,.0f%nKeuntungan       : Rp %,.0f (%s)%nBEP              : %,.0f kg TBS%n",
                totalModal, totalPendapatan, totalBiaya, keuntungan, keuntungan >= 0 ? "LABA" : "RUGI", nilaiBEP);
    }
    public String getIdAnalisis() { return getIdLaporan(); }
    @Override public void hitung() { hitungPendapatan(); hitungKeuntungan(); hitungBEP(); }  // OVERRIDING
    @Override public String tampilkan() { return tampilkanLaporanKeuangan(); }
}
