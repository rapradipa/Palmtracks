package sawit.model;

import java.time.LocalDate;
import sawit.exception.DataTidakValidException;

/** Abstract class turunan Entitas untuk data yang punya tanggal. Memakai pola TEMPLATE METHOD pada getRingkasan(). */
public abstract class Transaksi extends Entitas {
    private static final long serialVersionUID = 1L;
    private final LocalDate tanggal;

    protected Transaksi(String id, LocalDate tanggal) throws DataTidakValidException {
        super(id);
        if (tanggal == null) throw new DataTidakValidException("Tanggal wajib diisi");
        this.tanggal = tanggal;
    }

    public LocalDate getTanggal() { return tanggal; }
    protected abstract String getJenis();
    protected abstract String getDetail();

    @Override public final String getRingkasan() { return getJenis() + " " + getId() + " (" + tanggal + "): " + getDetail(); }
}
