package sawit.model;

import sawit.service.Repository;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

public class Lahan extends Entitas {
    private static final long serialVersionUID = 1L;
    private String lokasi; private double luasLahan; private int jumlahBlok;

    public Lahan(String idLahan, String lokasi, double luas, int blok) throws DataTidakValidException {
        super(idLahan); ubahLahan(lokasi, luas, blok);
    }
    public final void ubahLahan(String lokasi, double luas, int blok) throws DataTidakValidException {
        this.lokasi = Validasi.teks(lokasi, "Lokasi");
        if (luas <= 0 || blok <= 0) throw new DataTidakValidException("Luas lahan dan jumlah blok harus lebih dari 0");
        this.luasLahan = luas; this.jumlahBlok = blok;
    }
    public double hitungLuasLahan() { return luasLahan / jumlahBlok; } // ha per blok
    public double getLuasLahan() { return luasLahan; }
    public static Lahan dari(String[] f) throws DataTidakValidException {
        return new Lahan(f[0], f[1], Validasi.desimal(f[2], "Luas lahan"), Validasi.bulat(f[3], "Jumlah blok"));
    }
    public String getIdLahan() { return getId(); }
    public void tambahLahan(Repository<Lahan> repo) throws DataTidakValidException { repo.tambah(this); }
    public void hapusLahan(Repository<Lahan> repo) { repo.hapus(this); }
    @Override public Object[] toRow() { return new Object[]{getId(), lokasi, luasLahan, jumlahBlok, hitungLuasLahan()}; }
    @Override public String getRingkasan() { return "Lahan " + getId() + " - " + lokasi; }
}
