package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.exception.StokTidakCukupException;
import sawit.util.Validasi;

public class Pengiriman extends Transaksi implements Biayaable {
    private static final long serialVersionUID = 1L;
    private String tujuan; private double beratKirim, biayaTransportasi;

    public Pengiriman(String idPengiriman, LocalDate tanggal, String tujuan, double berat, double biaya) throws DataTidakValidException {
        super(idPengiriman, tanggal);
        this.tujuan = Validasi.teks(tujuan, "Tujuan");
        if (berat <= 0) throw new DataTidakValidException("Berat kirim harus lebih dari 0");
        this.beratKirim = berat; this.biayaTransportasi = biaya;
    }
    public void validasiStok(double stokTersedia) throws StokTidakCukupException {
        if (beratKirim > stokTersedia) throw new StokTidakCukupException(beratKirim, stokTersedia);
    }
    public double hitungBiayaTransportasi() { return biayaTransportasi; }
    @Override public double getBiaya() { return hitungBiayaTransportasi(); }
    public double getBeratKirim() { return beratKirim; }
    public static Pengiriman dari(String[] f) throws DataTidakValidException {
        return new Pengiriman(f[0], Validasi.tanggal(f[1], "Tanggal pengiriman"), f[2], Validasi.desimal(f[3], "Berat kirim"), Validasi.desimal(f[4], "Biaya transportasi"));
    }
    public String getIdPengiriman() { return getId(); }
    /** Validasi stok, catat pengiriman, lalu kurangi stok (FIFO). */
    public void catatPengiriman(Repository<Pengiriman> repo, Repository<Stok> repoStok) throws DataTidakValidException, StokTidakCukupException {
        validasiStok(Stok.hitungTotalStok(repoStok));
        repo.tambah(this);
        double sisa = beratKirim;
        for (Stok s : repoStok.getAll()) {
            if (sisa <= 0) break;
            double ambil = Math.min(sisa, s.hitungStokTersedia());
            if (ambil > 0) { s.kurangiStok(ambil); sisa -= ambil; }
        }
    }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), tujuan, beratKirim, biayaTransportasi}; }
    @Override protected String getJenis() { return "Pengiriman"; }
    @Override protected String getDetail() { return beratKirim + " kg ke " + tujuan; }
}
