package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

public class Bibit extends Transaksi {
    private static final long serialVersionUID = 1L;
    private String jenisBibit, kondisiBibit; private int jumlahBibit;

    public Bibit(String idBibit, LocalDate tanggalPembibitan, String jenis, int jumlah, String kondisi) throws DataTidakValidException {
        super(idBibit, tanggalPembibitan); ubahBibit(jenis, jumlah, kondisi);
    }
    public final void ubahBibit(String jenis, int jumlah, String kondisi) throws DataTidakValidException {
        this.jenisBibit = Validasi.teks(jenis, "Jenis bibit");
        this.kondisiBibit = Validasi.teks(kondisi, "Kondisi bibit");
        this.jumlahBibit = jumlah;
    }
    public String cekKondisiBibit() { return kondisiBibit.equalsIgnoreCase("baik") ? "Layak tanam" : "Belum layak tanam"; }
    public int getJumlahBibit() { return jumlahBibit; }
    public static Bibit dari(String[] f) throws DataTidakValidException {
        return new Bibit(f[0], Validasi.tanggal(f[1], "Tanggal pembibitan"), f[2], Validasi.bulat(f[3], "Jumlah bibit"), f[4]);
    }
    public String getIdBibit() { return getId(); }
    public void tambahBibit(Repository<Bibit> repo) throws DataTidakValidException { repo.tambah(this); }
    public static int hitungJumlahBibit(Repository<Bibit> repo) { int t = 0; for (Bibit b : repo.getAll()) t += b.getJumlahBibit(); return t; }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), jenisBibit, jumlahBibit, kondisiBibit, cekKondisiBibit()}; }
    @Override protected String getJenis() { return "Bibit"; }
    @Override protected String getDetail() { return jenisBibit + " x" + jumlahBibit; }
}
