package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

public class Perawatan extends Transaksi implements Biayaable {
    private static final long serialVersionUID = 1L;
    private String jenisPupuk; private double dosisPupuk, biayaPerawatan;

    public Perawatan(String idPerawatan, LocalDate tanggal, String pupuk, double dosis, double biaya) throws DataTidakValidException {
        super(idPerawatan, tanggal); ubahDataPerawatan(pupuk, dosis, biaya);
    }
    public final void ubahDataPerawatan(String pupuk, double dosis, double biaya) throws DataTidakValidException {
        this.jenisPupuk = Validasi.teks(pupuk, "Jenis pupuk"); this.dosisPupuk = dosis; this.biayaPerawatan = biaya;
    }
    public double hitungBiayaPerawatan() { return biayaPerawatan; }
    @Override public double getBiaya() { return hitungBiayaPerawatan(); }
    public static Perawatan dari(String[] f) throws DataTidakValidException {
        return new Perawatan(f[0], Validasi.tanggal(f[1], "Tanggal perawatan"), f[2], Validasi.desimal(f[3], "Dosis pupuk"), Validasi.desimal(f[4], "Biaya perawatan"));
    }
    public String getIdPerawatan() { return getId(); }
    public void catatPerawatan(Repository<Perawatan> repo) throws DataTidakValidException { repo.tambah(this); }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), jenisPupuk, dosisPupuk, biayaPerawatan}; }
    @Override protected String getJenis() { return "Perawatan"; }
    @Override protected String getDetail() { return jenisPupuk + " " + dosisPupuk + " kg"; }
}
