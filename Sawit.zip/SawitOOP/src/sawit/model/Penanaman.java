package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

public class Penanaman extends Transaksi {
    private static final long serialVersionUID = 1L;
    private String idBlok, namaPekerja; private int jumlahPohon;

    public Penanaman(String idPenanaman, LocalDate tanggalTanam, String idBlok, int jumlahPohon, String pekerja) throws DataTidakValidException {
        super(idPenanaman, tanggalTanam); ubahDataPenanaman(idBlok, jumlahPohon, pekerja);
    }
    public final void ubahDataPenanaman(String idBlok, int jumlahPohon, String pekerja) throws DataTidakValidException {
        this.idBlok = Validasi.teks(idBlok, "ID blok");
        this.namaPekerja = Validasi.teks(pekerja, "Nama pekerja");
        this.jumlahPohon = jumlahPohon;
    }
    public int hitungJumlahPohon() { return jumlahPohon; }
    public static Penanaman dari(String[] f) throws DataTidakValidException {
        return new Penanaman(f[0], Validasi.tanggal(f[1], "Tanggal tanam"), f[2], Validasi.bulat(f[3], "Jumlah pohon"), f[4]);
    }
    public String getIdPenanaman() { return getId(); }
    public void catatPenanaman(Repository<Penanaman> repo) throws DataTidakValidException { repo.tambah(this); }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), idBlok, jumlahPohon, namaPekerja}; }
    @Override protected String getJenis() { return "Penanaman"; }
    @Override protected String getDetail() { return jumlahPohon + " pohon di " + idBlok; }
}
