package sawit.model;

import java.io.Serializable;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

/** SUPERCLASS abstrak untuk semua data: menyimpan ID (ENCAPSULATION: private + getter/setter tervalidasi). */
public abstract class Entitas implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;

    protected Entitas(String id) throws DataTidakValidException { setId(id); }

    public String getId() { return id; }
    public final void setId(String id) throws DataTidakValidException { this.id = Validasi.teks(id, "ID"); }

    /** Dioverride tiap subclass (POLYMORPHISM): data satu baris tabel. */
    public abstract Object[] toRow();
    public abstract String getRingkasan();

    @Override public String toString() { return getRingkasan(); }
}
