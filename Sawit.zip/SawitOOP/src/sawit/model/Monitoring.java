package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

public class Monitoring extends Transaksi {
    private static final long serialVersionUID = 1L;
    private int umurTanaman, jumlahPohonHidup; private String kondisiTanaman;

    public Monitoring(String idMonitoring, LocalDate tanggal, int umur, int hidup, String kondisi) throws DataTidakValidException {
        super(idMonitoring, tanggal);
        this.umurTanaman = umur; this.jumlahPohonHidup = hidup; perbaruiKondisiTanaman(kondisi);
    }
    public final void perbaruiKondisiTanaman(String kondisi) throws DataTidakValidException { this.kondisiTanaman = Validasi.teks(kondisi, "Kondisi tanaman"); }
    public String cekKondisiTanaman() { return kondisiTanaman.equalsIgnoreCase("sehat") ? "Sehat" : "Perlu perhatian: " + kondisiTanaman; }
    public int hitungPohonHidup() { return jumlahPohonHidup; }
    public int getUmurTanaman() { return umurTanaman; }
    public static Monitoring dari(String[] f) throws DataTidakValidException {
        return new Monitoring(f[0], Validasi.tanggal(f[1], "Tanggal monitoring"), Validasi.bulat(f[2], "Umur tanaman"), Validasi.bulat(f[3], "Jumlah pohon hidup"), f[4]);
    }
    public String getIdMonitoring() { return getId(); }
    public void catatMonitoring(Repository<Monitoring> repo) throws DataTidakValidException { repo.tambah(this); }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), umurTanaman, jumlahPohonHidup, kondisiTanaman}; }
    @Override protected String getJenis() { return "Monitoring"; }
    @Override protected String getDetail() { return jumlahPohonHidup + " pohon hidup, " + cekKondisiTanaman(); }
}
