package sawit.model;

public class PrediksiPanen extends Laporan {
    private final double luasProduktif; private final int jumlahPohonProduktif, umurTanaman;
    private double estimasiProduksi; // ton TBS / tahun

    public PrediksiPanen(String id, double luas, int pohon, int umur) {
        super(id); this.luasProduktif = luas; this.jumlahPohonProduktif = pohon; this.umurTanaman = umur;
    }
    public double hitungPrediksiPanen() {
        double kgPerPohon = umurTanaman < 3 ? 0 : umurTanaman <= 5 ? 100 : umurTanaman <= 10 ? 150 : 180; // asumsi prototipe
        return estimasiProduksi = jumlahPohonProduktif * kgPerPohon / 1000.0;
    }
    public double hitungProduksiPerHektar() { return luasProduktif == 0 ? 0 : estimasiProduksi / luasProduktif; }
    public String tampilkanHasilPrediksi() {
        return String.format("Luas produktif     : %.2f ha%nPohon produktif    : %d%nUmur tanaman       : %d tahun%nEstimasi produksi  : %.2f ton TBS/tahun%nProduksi per hektar : %.2f ton/ha/tahun%n",
                luasProduktif, jumlahPohonProduktif, umurTanaman, estimasiProduksi, hitungProduksiPerHektar());
    }
    public String getIdPrediksi() { return getIdLaporan(); }
    @Override public void hitung() { hitungPrediksiPanen(); }              // OVERRIDING
    @Override public String tampilkan() { return tampilkanHasilPrediksi(); }
}
