package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

public class Panen extends Transaksi {
    private static final long serialVersionUID = 1L;
    private String idBlok, namaPemanen; private int jumlahTandan; private double beratTBS;

    public Panen(String idPanen, LocalDate tanggal, String idBlok, int tandan, double beratTBS, String pemanen) throws DataTidakValidException {
        super(idPanen, tanggal);
        this.idBlok = Validasi.teks(idBlok, "ID blok"); this.namaPemanen = Validasi.teks(pemanen, "Nama pemanen");
        this.jumlahTandan = tandan; this.beratTBS = beratTBS;
    }
    public double hitungBeratTBS() { return beratTBS; }
    public int hitungJumlahTandan() { return jumlahTandan; }
    public double getBeratTBS() { return beratTBS; }
    public static Panen dari(String[] f) throws DataTidakValidException {
        return new Panen(f[0], Validasi.tanggal(f[1], "Tanggal panen"), f[2], Validasi.bulat(f[3], "Jumlah tandan"), Validasi.desimal(f[4], "Berat TBS"), f[5]);
    }
    public String getIdPanen() { return getId(); }
    /** Mencatat panen dan otomatis menambah stok TBS. */
    public void catatPanen(Repository<Panen> repoPanen, Repository<Stok> repoStok) throws DataTidakValidException {
        Stok s = new Stok("S-" + getId(), getTanggal(), beratTBS, 0);
        if (repoStok.cari(s.getId()) != null) throw new DataTidakValidException("Stok untuk panen " + getId() + " sudah ada");
        repoPanen.tambah(this);
        repoStok.tambah(s);
    }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), idBlok, jumlahTandan, beratTBS, namaPemanen}; }
    @Override protected String getJenis() { return "Panen"; }
    @Override protected String getDetail() { return jumlahTandan + " tandan, " + beratTBS + " kg"; }
}
