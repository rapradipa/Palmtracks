package sawit.model;

/** INTERFACE: semua data yang menjadi komponen biaya. Dipakai untuk menjumlah biaya secara polimorfik. */
public interface Biayaable {
    double getBiaya();
}
