package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.exception.StokTidakCukupException;
import sawit.util.Validasi;

public class Stok extends Transaksi {
    private static final long serialVersionUID = 1L;
    private double beratMasuk, beratKeluar, stokTersedia;

    public Stok(String idStok, LocalDate tanggalMasuk, double masuk, double keluar) throws DataTidakValidException {
        super(idStok, tanggalMasuk);
        if (keluar > masuk) throw new DataTidakValidException("Berat keluar tidak boleh melebihi berat masuk");
        this.beratMasuk = masuk; this.beratKeluar = keluar; hitungStokTersedia();
    }
    public void tambahStok(double berat) { beratMasuk += berat; hitungStokTersedia(); }
    public void kurangiStok(double berat) throws StokTidakCukupException {
        if (!cekKetersediaanStok(berat)) throw new StokTidakCukupException(berat, hitungStokTersedia());
        beratKeluar += berat;
        hitungStokTersedia();
    }
    public double hitungStokTersedia() { return stokTersedia = beratMasuk - beratKeluar; }
    public boolean cekKetersediaanStok(double butuh) { return hitungStokTersedia() >= butuh; }
    public static Stok dari(String[] f) throws DataTidakValidException {
        return new Stok(f[0], Validasi.tanggal(f[1], "Tanggal masuk"), Validasi.desimal(f[2], "Berat masuk"), Validasi.desimal(f[3], "Berat keluar"));
    }
    public String getIdStok() { return getId(); }
    public static double hitungTotalStok(Repository<Stok> repo) { double t = 0; for (Stok s : repo.getAll()) t += s.hitungStokTersedia(); return t; }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), beratMasuk, beratKeluar, hitungStokTersedia()}; }
    @Override protected String getJenis() { return "Stok"; }
    @Override protected String getDetail() { return "tersedia " + hitungStokTersedia() + " kg"; }
}
