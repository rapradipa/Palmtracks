package sawit.model;

/** Abstract class untuk laporan hasil hitung (PrediksiPanen, AnalisisKeuangan). */
public abstract class Laporan {
    private final String idLaporan;
    protected Laporan(String idLaporan) { this.idLaporan = idLaporan; }
    public String getIdLaporan() { return idLaporan; }

    public abstract void hitung();
    public abstract String tampilkan();

    /** Template method: hitung lalu tampilkan. */
    public final String cetak() {
        hitung();
        return "=== " + getClass().getSimpleName().toUpperCase() + " [" + idLaporan + "] ===\n" + tampilkan();
    }
}
