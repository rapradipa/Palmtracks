package sawit.model;

import sawit.service.Repository;
import java.time.LocalDate;
import sawit.exception.DataTidakValidException;
import sawit.util.Validasi;

public class BiayaOperasional extends Transaksi implements Biayaable {
    private static final long serialVersionUID = 1L;
    private String jenisBiaya, keterangan; private double jumlahBiaya;

    public BiayaOperasional(String idBiaya, LocalDate tanggal, String jenis, double jumlah, String ket) throws DataTidakValidException {
        super(idBiaya, tanggal); ubahDataBiaya(jenis, jumlah, ket);
    }
    public final void ubahDataBiaya(String jenis, double jumlah, String ket) throws DataTidakValidException {
        this.jenisBiaya = Validasi.teks(jenis, "Jenis biaya"); this.keterangan = Validasi.teks(ket, "Keterangan"); this.jumlahBiaya = jumlah;
    }
    @Override public double getBiaya() { return jumlahBiaya; }
    public static BiayaOperasional dari(String[] f) throws DataTidakValidException {
        return new BiayaOperasional(f[0], Validasi.tanggal(f[1], "Tanggal biaya"), f[2], Validasi.desimal(f[3], "Jumlah biaya"), f[4]);
    }
    public String getIdBiaya() { return getId(); }
    public void catatBiaya(Repository<BiayaOperasional> repo) throws DataTidakValidException { repo.tambah(this); }
    public static double hitungTotalBiaya(Repository<BiayaOperasional> repo) { double t = 0; for (BiayaOperasional b : repo.getAll()) t += b.getBiaya(); return t; }
    @Override public Object[] toRow() { return new Object[]{getId(), getTanggal(), jenisBiaya, jumlahBiaya, keterangan}; }
    @Override protected String getJenis() { return "Biaya"; }
    @Override protected String getDetail() { return jenisBiaya + " Rp " + jumlahBiaya; }
}
