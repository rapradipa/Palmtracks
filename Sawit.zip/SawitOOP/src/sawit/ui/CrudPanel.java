package sawit.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sawit.exception.DataTidakValidException;
import sawit.exception.StokTidakCukupException;
import sawit.model.Entitas;
import sawit.service.Repository;

/** Panel CRUD generik untuk semua turunan Entitas. */
public class CrudPanel<T extends Entitas> extends JPanel {

    public interface Pembuat<E> { E buat(String[] field) throws DataTidakValidException; }
    public interface Aksi<E> { void jalankan(E obj) throws DataTidakValidException, StokTidakCukupException; }

    private final Repository<T> repo;
    private final Pembuat<T> pembuat;
    private final Aksi<T> aksiTambah;
    private final JTextField[] f;
    private final DefaultTableModel tm;
    private final JTable tb;

    public CrudPanel(String[] kolom, String[] extra, Repository<T> repo, Pembuat<T> pembuat, Aksi<T> aksi) {
        this.repo = repo; this.pembuat = pembuat;
        if (aksi != null) this.aksiTambah = aksi;
        else this.aksiTambah = new Aksi<T>() { public void jalankan(T o) throws DataTidakValidException { CrudPanel.this.repo.tambah(o); } };

        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel form = new JPanel(new GridLayout(0, 4, 8, 6));
        f = new JTextField[kolom.length];
        for (int i = 0; i < kolom.length; i++) { form.add(new JLabel(kolom[i])); f[i] = new JTextField(); form.add(f[i]); }
        if (kolom.length % 2 == 1) { form.add(new JLabel()); form.add(new JLabel()); }

        String[] heads = new String[kolom.length + extra.length];
        System.arraycopy(kolom, 0, heads, 0, kolom.length);
        System.arraycopy(extra, 0, heads, kolom.length, extra.length);
        tm = new DefaultTableModel(heads, 0) { @Override public boolean isCellEditable(int r, int c) { return false; } };
        tb = new JTable(tm);
        tb.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tb.getSelectionModel().addListSelectionListener(e -> {
            int r = tb.getSelectedRow();
            if (r >= 0 && !e.getValueIsAdjusting()) for (int i = 0; i < f.length; i++) f[i].setText(String.valueOf(tm.getValueAt(r, i)));
        });

        JButton bAdd = new JButton("Tambah"), bUpd = new JButton("Ubah"), bDel = new JButton("Hapus"), bClr = new JButton("Bersihkan");
        bAdd.addActionListener(e -> tambah());
        bUpd.addActionListener(e -> ubah());
        bDel.addActionListener(e -> hapus());
        bClr.addActionListener(e -> bersihkan());
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btns.add(bAdd); btns.add(bUpd); btns.add(bDel); btns.add(bClr);

        JPanel top = new JPanel(new BorderLayout(0, 8));
        top.add(form, BorderLayout.NORTH);
        top.add(btns, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(tb), BorderLayout.CENTER);
        refresh();
    }

    private String[] baca() {
        String[] v = new String[f.length];
        for (int i = 0; i < f.length; i++) v[i] = f[i].getText().trim();
        return v;
    }

    // EXCEPTION HANDLING: semua kesalahan input/stok ditangkap dan ditampilkan sebagai pesan.
    private void tambah() {
        try { aksiTambah.jalankan(pembuat.buat(baca())); refresh(); bersihkan(); }
        catch (DataTidakValidException | StokTidakCukupException ex) { pesan(ex.getMessage()); }
    }

    private void ubah() {
        int idx = tb.getSelectedRow();
        if (idx < 0) { pesan("Pilih baris yang akan diubah."); return; }
        try { repo.ubah(idx, pembuat.buat(baca())); refresh(); bersihkan(); }
        catch (DataTidakValidException ex) { pesan(ex.getMessage()); }
    }

    private void hapus() {
        int idx = tb.getSelectedRow();
        if (idx < 0) { pesan("Pilih baris yang akan dihapus."); return; }
        if (JOptionPane.showConfirmDialog(this, "Hapus data terpilih?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            repo.hapus(idx); refresh(); bersihkan();
        }
    }

    private void bersihkan() { for (JTextField t : f) t.setText(""); tb.clearSelection(); }
    private void pesan(String m) { JOptionPane.showMessageDialog(this, m, "Peringatan", JOptionPane.WARNING_MESSAGE); }

    public final void refresh() {
        tm.setRowCount(0);
        for (T o : repo.getAll()) tm.addRow(o.toRow());
    }
}
