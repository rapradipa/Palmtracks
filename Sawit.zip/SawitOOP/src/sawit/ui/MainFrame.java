package sawit.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import sawit.exception.DataTidakValidException;
import sawit.model.*;
import sawit.service.Repository;
import sawit.service.SistemKebun;

public class MainFrame extends JFrame {
    private final SistemKebun sistem = new SistemKebun();
    private final JTabbedPane tabs = new JTabbedPane();
    private final List<CrudPanel<?>> panels = new ArrayList<>();

    public MainFrame() {
        super("Sistem Informasi Perkebunan Kelapa Sawit (OOP Prototype)");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setSize(1050, 620);
        setLocationRelativeTo(null);

        try { if (!sistem.muat()) sistem.isiDataContoh(); }
        catch (IOException | ClassNotFoundException | DataTidakValidException e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data: " + e.getMessage());
        }

        tab("Lahan", new String[]{"idLahan", "lokasi", "luasLahan (ha)", "jumlahBlok"}, new String[]{"luas/blok (ha)"}, sistem.getLahan(), Lahan::dari, x -> x.tambahLahan(sistem.getLahan()));
        tab("Bibit", new String[]{"idBibit", "tanggalPembibitan (yyyy-MM-dd)", "jenisBibit", "jumlahBibit", "kondisiBibit (Baik/Kurang)"}, new String[]{"status"}, sistem.getBibit(), Bibit::dari, x -> x.tambahBibit(sistem.getBibit()));
        tab("Penanaman", new String[]{"idPenanaman", "tanggalTanam", "idBlok", "jumlahPohon", "namaPekerja"}, new String[]{}, sistem.getPenanaman(), Penanaman::dari, x -> x.catatPenanaman(sistem.getPenanaman()));
        tab("Perawatan", new String[]{"idPerawatan", "tanggalPerawatan", "jenisPupuk", "dosisPupuk (kg)", "biayaPerawatan (Rp)"}, new String[]{}, sistem.getPerawatan(), Perawatan::dari, x -> x.catatPerawatan(sistem.getPerawatan()));
        tab("Monitoring", new String[]{"idMonitoring", "tanggalMonitoring", "umurTanaman (th)", "jumlahPohonHidup", "kondisiTanaman"}, new String[]{}, sistem.getMonitoring(), Monitoring::dari, x -> x.catatMonitoring(sistem.getMonitoring()));
        tab("Panen", new String[]{"idPanen", "tanggalPanen", "idBlok", "jumlahTandan", "beratTBS (kg)", "namaPemanen"}, new String[]{}, sistem.getPanen(), Panen::dari, sistem::catatPanen);
        tab("Stok", new String[]{"idStok", "tanggalMasuk", "beratMasuk (kg)", "beratKeluar (kg)"}, new String[]{"stokTersedia (kg)"}, sistem.getStok(), Stok::dari, null);
        tab("Pengiriman", new String[]{"idPengiriman", "tanggalPengiriman", "tujuan", "beratKirim (kg)", "biayaTransportasi (Rp)"}, new String[]{}, sistem.getPengiriman(), Pengiriman::dari, sistem::catatPengiriman);
        tab("Modal", new String[]{"idModal", "tanggalModal", "jumlahModal (Rp)", "keterangan"}, new String[]{}, sistem.getModal(), Modal::dari, x -> x.catatModal(sistem.getModal()));
        tab("Biaya Operasional", new String[]{"idBiaya", "tanggalBiaya", "jenisBiaya", "jumlahBiaya (Rp)", "keterangan"}, new String[]{}, sistem.getBiaya(), BiayaOperasional::dari, x -> x.catatBiaya(sistem.getBiaya()));
        tabs.addTab("Prediksi & Keuangan", panelLaporan());
        tabs.addChangeListener(e -> { for (CrudPanel<?> p : panels) p.refresh(); });

        JMenuBar mb = new JMenuBar(); JMenu m = new JMenu("File"); JMenuItem simpan = new JMenuItem("Simpan data");
        simpan.addActionListener(e -> simpan(false)); m.add(simpan); mb.add(m); setJMenuBar(mb);
        add(tabs);

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { simpan(true); dispose(); System.exit(0); }
        });
    }

    private <T extends Entitas> void tab(String judul, String[] kolom, String[] extra, Repository<T> repo,
                                         CrudPanel.Pembuat<T> pembuat, CrudPanel.Aksi<T> aksi) {
        CrudPanel<T> p = new CrudPanel<>(kolom, extra, repo, pembuat, aksi);
        panels.add(p);
        tabs.addTab(judul, p);
    }

    private void simpan(boolean diam) {
        try { sistem.simpan(); if (!diam) JOptionPane.showMessageDialog(this, "Data tersimpan ke data_sawit.dat"); }
        catch (IOException ex) { JOptionPane.showMessageDialog(this, "Gagal menyimpan: " + ex.getMessage()); }
    }

    private JPanel panelLaporan() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JTextField harga = new JTextField("2500", 8);
        JButton btn = new JButton("Hitung Prediksi & Laporan Keuangan");
        JTextArea out = new JTextArea();
        out.setEditable(false);
        out.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Harga TBS (Rp/kg):")); top.add(harga); top.add(btn);

        btn.addActionListener(e -> {
            try {
                double h = Double.parseDouble(harga.getText().trim());
                if (h <= 0) throw new NumberFormatException();
                // POLYMORPHISM: dua jenis laporan diperlakukan sebagai Laporan
                Laporan[] laporan = { sistem.buatPrediksi(), sistem.buatAnalisis(h) };
                StringBuilder sb = new StringBuilder("=== RINGKASAN ===\n");
                sb.append(String.format("Total bibit      : %d%nPohon ditanam    : %d%nPohon hidup      : %d%nTotal tandan     : %d%nTotal berat TBS  : %,.0f kg%nStok tersedia    : %,.0f kg%n%n",
                        sistem.hitungJumlahBibit(), sistem.hitungJumlahPohonTanam(), sistem.hitungPohonHidup(),
                        sistem.hitungJumlahTandan(), sistem.hitungBeratTBS(), sistem.hitungStokTersedia()));
                for (Laporan l : laporan) sb.append(l.cetak()).append('\n');
                out.setText(sb.toString());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Harga TBS harus berupa angka lebih dari 0.");
            }
        });
        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(out), BorderLayout.CENTER);
        return p;
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo i : UIManager.getInstalledLookAndFeels())
                if ("Nimbus".equals(i.getName())) { UIManager.setLookAndFeel(i.getClassName()); break; }
        } catch (Exception ignored) { }
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
